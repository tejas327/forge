# Forge — Phone-First Autonomous Web Agency

A complete working demonstration of an autonomous AI web agency system. Built as a mobile-first PWA with React + Node/Express + SQLite.

## Features Implemented

**✅ UI/UX**
- Premium dark minimal interface with DM Sans + Space Grotesk
- Phone-first responsive design (simulated phone frame on desktop)
- 4 tabs: Pipeline, Agents, Activity Feed, Clients
- Beautiful modals, notifications, live status indicators

**✅ Agent Manager**
- 4 pre-configured agents (Researcher, Builder, Deployer, Manager)
- Toggle pause/resume with real state
- Model + role + tools display

**✅ Pipeline Builder**
- Visual 5-stage pipeline (Prospect → Research → Build → Deploy → Manage)
- Client cards with live status
- One-click "Launch Pipeline" that triggers autonomous flow
- Mock autonomous progression between stages

**✅ Activity Feed**
- Real-time looking activity log with agent, model, duration, results
- Beautiful formatted entries that update live

**✅ Approval System**
- Approval queue for sensitive actions (deploy, outreach)
- Beautiful approval modal with one-tap approve/reject
- Notifications when approvals are needed

**✅ Backend**
- Express server with SQLite persistence
- Full CRUD for agents, clients, activities, pipeline stages, approvals
- Mock agent execution logic with realistic timing and results
- End-to-end flow simulation (no real external API keys needed)

**✅ PWA Ready**
- Mobile optimized viewport, manifest ready, installable

## How to Run

### 1. Backend
```bash
cd backend
npm install
npm run dev
```
Runs on http://localhost:3001

### 2. Frontend
```bash
cd frontend
npm install
npm run dev
```
Runs on http://localhost:5173 with proxy to backend

### 3. Try the full flow:
1. Go to Pipeline tab
2. Tap "NEW CLIENT"
3. Enter a business name (e.g. "Pixel Coffee")
4. Watch the pipeline progress automatically
5. Approve the deployment when prompted
6. Check Activity Feed and Agents

The system simulates:
- Competitor/SEO research (Researcher)
- Full website generation (Builder using MiniMax simulation)
- GitHub + Netlify deployment (Deployer)
- Live site URL generation
- Approval gates
- Activity logging

## Tech Stack
- **Frontend**: React 19 + Vite + Tailwind CSS v4 + Lucide Icons + Framer Motion ready
- **Backend**: Node.js + Express + SQLite
- **Database**: Single file SQLite (no setup)
- **Styling**: Dark premium product feel with perfect mobile UX

## Deployment Notes
- **Frontend**: Deploy `frontend/dist` to Netlify (PWA ready)
- **Backend**: Deploy to Railway.app (uses SQLite file, works well for demos)
- Real API keys for Serper, GitHub, Netlify, Ahrefs, MiniMax can be added to the agent execution functions.

## Future Enhancements (not in this demo)
- Real LLM calls to MiniMax/Claude/GPT via their APIs
- Actual GitHub + Netlify API integrations
- Serper web search and Ahrefs SEO data
- Real PWA push notifications for approvals
- MCP tool connections

---

**Built as a complete working prototype in the workspace.** All core flows are functional.

Enjoy your autonomous web agency!
