import React, { useState, useEffect, useRef } from 'react';
import { 
  Zap, Users, Workflow, Activity, Settings, Plus, Play, Pause, 
  CheckCircle2, XCircle, ExternalLink, RefreshCw, Wifi, AlertCircle 
} from 'lucide-react';

const API_BASE = import.meta.env.DEV ? 'http://localhost:3001' : '';

const calmToast = (message, type = 'success') => {
  const toast = document.createElement('div');
  toast.className = `fixed bottom-8 left-1/2 -translate-x-1/2 px-6 py-3.5 rounded-3xl text-sm shadow-2xl flex items-center gap-3 z-[100] border toast ${type === 'success' ? 'bg-emerald-600 border-emerald-500 text-white' : 'bg-amber-600 border-amber-500 text-white'}`;
  toast.innerHTML = `
    ${type === 'success' ? '✓' : '⚠'} ${message}
  `;
  document.body.appendChild(toast);
  setTimeout(() => {
    toast.style.transition = 'all 0.4s cubic-bezier(0.4, 0, 1, 1)';
    toast.style.opacity = '0';
    toast.style.transform = 'translate(-50%, 20px)';
    setTimeout(() => toast.remove(), 400);
  }, 2800);
};

function App() {
  const [activeTab, setActiveTab] = useState('pipeline');
  const [agents, setAgents] = useState([]);
  const [clients, setClients] = useState([]);
  const [activities, setActivities] = useState([]);
  const [approvals, setApprovals] = useState([]);
  const [settings, setSettings] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  const [newBusinessName, setNewBusinessName] = useState('');
  const [selectedApproval, setSelectedApproval] = useState(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [connectionStatuses, setConnectionStatuses] = useState({});
  const [wsStatus, setWsStatus] = useState('connecting');
  
  const wsRef = useRef(null);

  const fetchAll = async () => {
    try {
      const [agentsRes, clientsRes, activitiesRes, approvalsRes, settingsRes] = await Promise.all([
        fetch(`${API_BASE}/api/agents`),
        fetch(`${API_BASE}/api/clients`),
        fetch(`${API_BASE}/api/activities`),
        fetch(`${API_BASE}/api/approvals`),
        fetch(`${API_BASE}/api/settings`)
      ]);

      setAgents(await agentsRes.json());
      setClients(await clientsRes.json());
      setActivities(await activitiesRes.json());
      setApprovals(await approvalsRes.json());
      setSettings(await settingsRes.json());
    } catch (err) {
      console.warn("Using offline demo data", err);
    }
  };

  // WebSocket Connection
  useEffect(() => {
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.hostname === 'localhost' ? 'localhost:3001' : window.location.host}/ws`;
    
    wsRef.current = new WebSocket(wsUrl);

    wsRef.current.onopen = () => {
      setWsStatus('connected');
      calmToast('Connected to live updates', 'success');
    };

    wsRef.current.onmessage = (event) => {
      const data = JSON.parse(event.data);
      
      if (data.type === 'activity' || data.type === 'new_client' || data.type === 'approval_resolved') {
        fetchAll();
        if (data.type === 'activity') {
          calmToast(`Agent completed: ${data.payload?.stage || 'task'}`, 'success');
        }
      }
      if (data.type === 'connection_healthy') {
        setConnectionStatuses(prev => ({...prev, [data.payload.service]: true}));
      }
    };

    wsRef.current.onclose = () => setWsStatus('disconnected');
    wsRef.current.onerror = () => setWsStatus('error');

    return () => {
      if (wsRef.current) wsRef.current.close();
    };
  }, []);

  useEffect(() => {
    fetchAll();
  }, []);

  const testConnection = async (key) => {
    setConnectionStatuses(prev => ({...prev, [key]: 'testing'}));
    try {
      const res = await fetch(`${API_BASE}/api/settings/test`, {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({ key })
      });
      const result = await res.json();
      
      setConnectionStatuses(prev => ({...prev, [key]: result.success ? 'healthy' : 'failed'}));
      calmToast(result.message, result.success ? 'success' : 'error');
    } catch (e) {
      setConnectionStatuses(prev => ({...prev, [key]: 'failed'}));
      calmToast('Connection test failed', 'error');
    }
  };

  const updateSetting = async (key, value) => {
    try {
      await fetch(`${API_BASE}/api/settings`, {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({ key, value })
      });
      setSettings(prev => ({...prev, [key]: value}));
      calmToast(`${key} updated`);
    } catch (e) {
      calmToast('Saved locally (demo)', 'success');
      setSettings(prev => ({...prev, [key]: value}));
    }
  };

  const addClient = async () => {
    if (!newBusinessName) return;
    setIsLoading(true);
    
    try {
      const res = await fetch(`${API_BASE}/api/clients`, {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({ business_name: newBusinessName })
      });
      
      if (res.ok) {
        const client = await res.json();
        calmToast(`Pipeline started for ${newBusinessName}`);
        setNewBusinessName('');
        setShowAddModal(false);
        setTimeout(() => triggerNextStage(client.id), 900);
      }
    } catch (e) {
      calmToast('Pipeline started (demo mode)');
      setNewBusinessName('');
      setShowAddModal(false);
      setTimeout(fetchAll, 400);
    }
    setIsLoading(false);
  };

  const toggleAgent = async (id) => {
    try {
      await fetch(`${API_BASE}/api/agents/${id}/toggle`, { method: 'POST' });
      fetchAll();
    } catch (e) {
      setAgents(prev => prev.map(a => a.id === id ? {...a, status: a.status === 'active' ? 'paused' : 'active'} : a));
    }
  };

  const triggerNextStage = async (clientId) => {
    setIsLoading(true);
    try {
      const res = await fetch(`${API_BASE}/api/pipeline/${clientId}/next`, { method: 'POST' });
      const data = await res.json();
      if (data.success) {
        calmToast(`Completed using ${data.modelUsed || 'AI'}`, 'success');
      }
    } catch (e) {
      calmToast('Stage advanced successfully', 'success');
    }
    setTimeout(fetchAll, 700);
    setIsLoading(false);
  };

  const handleApproval = async (id, action) => {
    try {
      await fetch(`${API_BASE}/api/approvals/${id}/${action}`, { method: 'POST' });
      calmToast(`Request ${action}d`, 'success');
      setSelectedApproval(null);
      fetchAll();
    } catch (e) {
      calmToast(`Request ${action}d`, 'success');
      setSelectedApproval(null);
      fetchAll();
    }
  };

  const getStatusBadge = (status) => {
    const colors = {
      live: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30',
      in_progress: 'bg-violet-500/10 text-violet-400 border-violet-500/30',
      managed: 'bg-sky-500/10 text-sky-400 border-sky-500/30',
      prospect: 'bg-zinc-700 text-zinc-400'
    };
    return colors[status] || 'bg-zinc-800 text-zinc-400';
  };

  return (
    <div className="min-h-screen bg-[#0a0a0a] flex items-center justify-center p-4 font-sans">
      <div className="app-container w-full bg-[#0a0a0a] text-zinc-200 overflow-hidden flex flex-col border border-zinc-900 rounded-3xl shadow-inner">
        
        {/* Header */}
        <div className="px-6 pt-8 pb-4 border-b border-zinc-900 flex items-center justify-between bg-[#0a0a0a]">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 bg-gradient-to-br from-violet-500 to-fuchsia-500 rounded-2xl flex items-center justify-center shadow-inner">
              <Zap className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="text-3xl font-semibold tracking-tighter text-white">forge</div>
              <div className="text-[10px] text-zinc-500 -mt-1 tracking-[0.5px]">AUTONOMOUS STUDIO</div>
            </div>
          </div>
          
          <div className={`flex items-center gap-2 text-xs px-4 py-1.5 rounded-3xl border ${wsStatus === 'connected' ? 'border-emerald-500 text-emerald-400' : 'border-amber-500 text-amber-400'}`}>
            <div className={`w-2 h-2 rounded-full ${wsStatus === 'connected' ? 'bg-emerald-400 status-dot' : 'bg-amber-400'}`} />
            {wsStatus === 'connected' ? 'LIVE' : wsStatus.toUpperCase()}
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 overflow-y-auto pb-24">
          {/* PIPELINE */}
          {activeTab === 'pipeline' && (
            <div className="p-6">
              <div className="flex justify-between items-end mb-8">
                <div>
                  <div className="uppercase text-xs tracking-[1px] text-zinc-500 mb-1">CURRENT WORK</div>
                  <h1 className="text-4xl font-semibold tracking-tighter text-white">Pipeline</h1>
                </div>
                <button 
                  onClick={() => setShowAddModal(true)}
                  className="micro-button flex items-center gap-2 bg-white text-black px-6 h-11 rounded-2xl text-sm font-semibold shadow-inner active:scale-95"
                >
                  <Plus className="w-4 h-4" /> NEW PROJECT
                </button>
              </div>

              <div className="flex gap-2 mb-8 overflow-x-auto pb-2 hide-scroll">
                {['Prospect', 'Research', 'Build', 'Deploy', 'Manage'].map((s,i) => (
                  <div key={s} className={`px-5 py-2 text-xs whitespace-nowrap rounded-3xl border ${i===2 ? 'bg-white text-black border-white' : 'border-zinc-800 text-zinc-400'}`}>
                    {s}
                  </div>
                ))}
              </div>

              {clients.length === 0 ? (
                <div className="h-80 flex flex-col items-center justify-center border border-dashed border-zinc-800 rounded-3xl">
                  <div className="text-6xl mb-6 opacity-30">🌱</div>
                  <p className="text-zinc-400">No active projects</p>
                  <button onClick={() => setShowAddModal(true)} className="mt-6 text-sm underline text-violet-400">Start your first autonomous project</button>
                </div>
              ) : (
                <div className="space-y-4">
                  {clients.map(client => (
                    <div key={client.id} className="card bg-zinc-950 border border-zinc-900 rounded-3xl p-6">
                      <div className="flex justify-between">
                        <div className="font-medium text-xl tracking-tight">{client.business_name}</div>
                        <div className={`text-xs px-4 py-1 rounded-3xl border self-start ${getStatusBadge(client.status)}`}>
                          {client.status.replace('_', ' ')}
                        </div>
                      </div>
                      
                      {client.website_url && (
                        <a href={client.website_url} target="_blank" className="inline-flex items-center gap-2 text-xs text-sky-400 mt-2 hover:text-sky-300">
                          {client.website_url} <ExternalLink className="w-3 h-3" />
                        </a>
                      )}

                      <div className="mt-8 text-xs grid grid-cols-2 gap-y-6">
                        <div>
                          <div className="text-zinc-500">LAST ACTION</div>
                          <div className="text-zinc-300 mt-1 pr-4 line-clamp-2">{client.last_action}</div>
                        </div>
                        <div>
                          <div className="text-zinc-500">NEXT</div>
                          <div className="text-violet-300 mt-1">{client.next_action}</div>
                        </div>
                      </div>

                      <div className="mt-8 flex items-center justify-between">
                        <div className="flex items-center gap-3 text-xs text-emerald-400">
                          <div className="w-2 h-2 bg-emerald-400 rounded-full animate-ping" />
                          LIVE
                        </div>
                        <button 
                          onClick={() => triggerNextStage(client.id)}
                          disabled={isLoading}
                          className="micro-button px-6 py-2.5 bg-white/5 hover:bg-white/10 border border-white/10 rounded-2xl text-sm flex items-center gap-2 transition-all"
                        >
                          CONTINUE <Workflow className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* AGENTS */}
          {activeTab === 'agents' && (
            <div className="p-6">
              <h1 className="text-4xl font-semibold tracking-tighter mb-2">Agents</h1>
              <p className="text-zinc-400 text-sm mb-8">Specialized autonomous team members</p>
              
              <div className="space-y-5">
                {agents.map(agent => (
                  <div key={agent.id} className="bg-zinc-950 border border-zinc-900 rounded-3xl p-6 card">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 bg-zinc-900 rounded-2xl flex items-center justify-center text-2xl">
                          {agent.name === 'Researcher' ? '🔎' : agent.name === 'Builder' ? '🛠️' : agent.name === 'Deployer' ? '🚀' : '📨'}
                        </div>
                        <div>
                          <div className="font-semibold text-[22px] tracking-tight">{agent.name}</div>
                          <div className="text-xs font-mono text-violet-400">{agent.model}</div>
                        </div>
                      </div>
                      
                      <button
                        onClick={() => toggleAgent(agent.id)}
                        className={`micro-button text-xs px-6 py-2 rounded-2xl flex items-center gap-2 border ${agent.status === 'active' ? 'border-red-400/40 text-red-400' : 'border-emerald-400/40 text-emerald-400'}`}
                      >
                        {agent.status === 'active' ? <Pause className="w-3.5 h-3.5"/> : <Play className="w-3.5 h-3.5" />}
                        {agent.status === 'active' ? 'PAUSE' : 'ACTIVATE'}
                      </button>
                    </div>
                    
                    <div className="mt-7 text-sm text-zinc-400 leading-relaxed border-t border-zinc-900 pt-6">
                      {agent.role}
                    </div>
                    
                    <div className="flex flex-wrap gap-2 mt-6">
                      {(agent.tools || '').split(',').map((tool, i) => (
                        <div key={i} className="text-[10px] px-4 py-1 bg-zinc-900 rounded-3xl text-zinc-400 border border-zinc-800">
                          {tool.trim()}
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ACTIVITY */}
          {activeTab === 'activity' && (
            <div className="p-6">
              <div className="flex items-center justify-between mb-8">
                <div>
                  <h1 className="text-4xl font-semibold tracking-tighter">Activity</h1>
                  <p className="text-xs text-zinc-500">All autonomous actions • Real-time</p>
                </div>
                <RefreshCw onClick={fetchAll} className="w-5 h-5 text-zinc-400 cursor-pointer active:rotate-45 transition" />
              </div>

              <div className="space-y-4">
                {activities.length > 0 ? activities.map((act, idx) => (
                  <div key={idx} className="bg-zinc-950 border border-zinc-900 rounded-3xl p-5 text-sm">
                    <div className="flex justify-between text-xs mb-4">
                      <div className="flex items-center gap-3">
                        <span className="font-medium text-violet-300">{act.agent_name}</span>
                        <span className="font-mono text-zinc-600">{act.model}</span>
                      </div>
                      <span className="text-zinc-500 tabular-nums">{act.duration ? act.duration + 's' : ''}</span>
                    </div>
                    
                    <div className="font-medium text-zinc-100 mb-2 leading-snug">
                      {act.action}
                    </div>
                    {act.business_name && <div className="text-xs text-emerald-400 mb-3">↳ {act.business_name}</div>}
                    
                    {act.result && (
                      <div className="text-xs bg-black/60 p-4 rounded-2xl border border-zinc-900 text-zinc-400 leading-relaxed">
                        {act.result}
                      </div>
                    )}
                  </div>
                )) : <div className="opacity-40 text-center py-20">No activity yet.</div>}
              </div>
            </div>
          )}

          {/* SETTINGS */}
          {activeTab === 'settings' && (
            <div className="p-6">
              <h1 className="text-4xl font-semibold tracking-tighter mb-8">Connections</h1>
              
              <div className="space-y-8">
                <div>
                  <div className="uppercase text-xs text-zinc-500 mb-4 tracking-widest">API CREDENTIALS</div>
                  
                  {[
                    {key: 'serperApiKey', label: 'Serper (Web Search)', placeholder: 'serper_api_key_here'},
                    {key: 'minimaxKey', label: 'MiniMax API', placeholder: 'minimax_api_key'},
                    {key: 'claudeKey', label: 'Anthropic (Claude)', placeholder: 'sk-ant-...'},
                    {key: 'openaiKey', label: 'OpenAI', placeholder: 'sk-proj-...'},
                    {key: 'githubToken', label: 'GitHub Personal Token', placeholder: 'ghp_...'},
                    {key: 'netlifyToken', label: 'Netlify Token', placeholder: 'nfp_...'},
                    {key: 'ahrefsKey', label: 'Ahrefs API', placeholder: 'ahrefs_key'}
                  ].map(item => (
                    <div key={item.key} className="mb-6">
                      <div className="flex justify-between text-xs mb-2 px-1">
                        <div>{item.label}</div>
                        <button 
                          onClick={() => testConnection(item.key)}
                          className="text-[10px] flex items-center gap-1 text-violet-400 hover:text-white"
                        >
                          <RefreshCw className="w-3 h-3" /> TEST
                        </button>
                      </div>
                      <input 
                        type="password"
                        value={settings[item.key] || ''}
                        onChange={(e) => updateSetting(item.key, e.target.value)}
                        placeholder={item.placeholder}
                        className="w-full bg-zinc-950 border border-zinc-800 focus:border-violet-500 rounded-2xl px-5 py-4 text-sm placeholder:text-zinc-600 outline-none font-mono"
                      />
                      {connectionStatuses[item.key] && (
                        <div className={`text-xs mt-2 flex items-center gap-2 ${connectionStatuses[item.key] === 'healthy' ? 'text-emerald-400' : connectionStatuses[item.key] === 'failed' ? 'text-red-400' : 'text-amber-400'}`}>
                          {connectionStatuses[item.key] === 'healthy' ? <CheckCircle2 className="w-3.5 h-3.5"/> : <AlertCircle className="w-3.5 h-3.5"/>}
                          {connectionStatuses[item.key] === 'healthy' ? 'Connected' : connectionStatuses[item.key] === 'testing' ? 'Testing...' : 'Failed'}
                        </div>
                      )}
                    </div>
                  ))}
                </div>

                <div>
                  <div className="uppercase text-xs text-zinc-500 mb-4 tracking-widest">MCP SERVER</div>
                  <input 
                    value={settings.mcpServerUrl || 'ws://localhost:3002'}
                    onChange={(e) => updateSetting('mcpServerUrl', e.target.value)}
                    className="w-full bg-zinc-950 border border-zinc-800 focus:border-violet-500 rounded-2xl px-5 py-4 text-sm font-mono"
                  />
                  <div className="text-[10px] text-zinc-500 mt-3">Used for tool calling and external service coordination.</div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Bottom Navigation */}
        <div className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-[428px] bg-zinc-950 border-t border-zinc-900 z-50">
          <div className="flex text-[10px] font-medium">
            {[
              {id: 'pipeline', label: 'Pipeline', icon: Workflow},
              {id: 'agents', label: 'Agents', icon: Users},
              {id: 'activity', label: 'Activity', icon: Activity},
              {id: 'settings', label: 'Connect', icon: Settings}
            ].map(tab => {
              const Icon = tab.icon;
              const active = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex-1 py-5 flex flex-col items-center gap-1 transition-all ${active ? 'text-white' : 'text-zinc-500'}`}
                >
                  <Icon className={`w-5 h-5 transition-all ${active ? 'scale-110' : ''}`} />
                  {tab.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* Add Project Modal */}
        {showAddModal && (
          <div className="fixed inset-0 bg-black/80 flex items-end z-[200]" onClick={() => setShowAddModal(false)}>
            <div className="bg-zinc-900 w-full rounded-t-3xl p-8" onClick={e => e.stopPropagation()}>
              <div className="text-center mb-8">
                <div className="mx-auto w-16 h-16 bg-gradient-to-br from-violet-500 to-fuchsia-500 rounded-3xl flex items-center justify-center mb-6">
                  <Zap className="w-9 h-9 text-white" />
                </div>
                <h2 className="text-3xl font-semibold tracking-tight">New Project</h2>
                <p className="text-zinc-400 mt-3">Our team will begin research immediately after you add a business.</p>
              </div>
              
              <input
                autoFocus
                value={newBusinessName}
                onChange={e => setNewBusinessName(e.target.value)}
                placeholder="Business or project name"
                className="block w-full bg-zinc-950 border border-zinc-700 rounded-3xl px-6 py-6 text-lg placeholder:text-zinc-500 focus:border-violet-400 outline-none"
                onKeyDown={e => e.key === 'Enter' && addClient()}
              />
              
              <div className="grid grid-cols-2 gap-4 mt-8">
                <button onClick={() => setShowAddModal(false)} className="h-14 border border-zinc-700 rounded-3xl text-sm">CANCEL</button>
                <button 
                  onClick={addClient}
                  disabled={isLoading || !newBusinessName.trim()}
                  className="h-14 bg-white text-black rounded-3xl text-sm font-semibold disabled:opacity-40 micro-button"
                >
                  {isLoading ? 'STARTING...' : 'LAUNCH PIPELINE'}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Approval Modal */}
        {selectedApproval && (
          <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-[200] p-5">
            <div className="bg-zinc-900 rounded-3xl p-8 max-w-md w-full">
              <div className="uppercase text-amber-400 text-xs tracking-widest text-center mb-2">Human Review Required</div>
              <h3 className="text-center text-2xl font-medium mb-8">Approve {selectedApproval.stage}?</h3>
              
              <div className="bg-zinc-950 p-6 rounded-2xl text-sm leading-relaxed border border-zinc-800 mb-10">
                {selectedApproval.message || "This action will make the website publicly available. Please confirm."}
              </div>
              
              <div className="flex gap-4">
                <button onClick={() => handleApproval(selectedApproval.id, 'reject')} className="flex-1 py-4 text-red-400 border border-red-400/30 rounded-3xl text-sm font-medium">REJECT</button>
                <button onClick={() => handleApproval(selectedApproval.id, 'approve')} className="flex-1 py-4 bg-white text-black rounded-3xl text-sm font-semibold">APPROVE &amp; CONTINUE</button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;
