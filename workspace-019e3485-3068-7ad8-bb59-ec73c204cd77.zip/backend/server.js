const express = require('express');
const cors = require('cors');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const bodyParser = require('body-parser');

const app = express();
const PORT = process.env.PORT || 3001;
const WS_CLIENTS = new Set();

// Enhanced CORS
app.use(cors({
  origin: true,
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));

app.use(bodyParser.json({ limit: '10mb' }));
app.use(express.static(path.join(__dirname, '../frontend/dist')));

// Database with better error handling
const dbPath = path.join(__dirname, 'database.sqlite');
const db = new sqlite3.Database(dbPath, (err) => {
  if (err) console.error('Database connection error:', err);
  else console.log('Connected to SQLite');
});

// Graceful shutdown
process.on('SIGINT', () => {
  console.log('Shutting down gracefully...');
  db.close(() => process.exit(0));
});

db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS agents (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT UNIQUE,
    model TEXT,
    role TEXT,
    tools TEXT,
    status TEXT DEFAULT 'active',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS clients (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    business_name TEXT,
    status TEXT DEFAULT 'prospect',
    website_url TEXT,
    last_action TEXT,
    next_action TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS activities (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    client_id INTEGER,
    agent_name TEXT,
    action TEXT,
    model TEXT,
    duration INTEGER,
    result TEXT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS pipeline_stages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    client_id INTEGER,
    stage TEXT,
    assigned_agent TEXT,
    status TEXT DEFAULT 'pending',
    approved INTEGER DEFAULT 0
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS approvals (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    client_id INTEGER,
    stage TEXT,
    message TEXT,
    status TEXT DEFAULT 'pending',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);

  // Default settings
  const defaults = {
    serperApiKey: '',
    githubToken: '',
    netlifyToken: '',
    ahrefsKey: '',
    minimaxKey: '',
    claudeKey: '',
    openaiKey: '',
    mcpServerUrl: 'ws://localhost:3002'
  };

  Object.keys(defaults).forEach(key => {
    db.run("INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)", [key, defaults[key]]);
  });

  // Default agents
  db.get("SELECT COUNT(*) as count FROM agents", (err, row) => {
    if (row.count === 0) {
      const defaultAgents = [
        ['Researcher', 'Claude', 'Deep market, competitor, and keyword research using latest data', 'Web Search, Ahrefs', 'active'],
        ['Builder', 'MiniMax', 'Creates beautiful, fast, conversion-focused websites from scratch', 'File System, Code Generation', 'active'],
        ['Deployer', 'GPT-4o', 'Handles GitHub commits, Netlify deployment, and DNS', 'GitHub, Netlify', 'active'],
        ['Outreach', 'Claude', 'LinkedIn messaging and follow-up with human approval', 'LinkedIn', 'paused']
      ];
      
      const stmt = db.prepare("INSERT INTO agents (name, model, role, tools, status) VALUES (?, ?, ?, ?, ?)");
      defaultAgents.forEach(agent => stmt.run(agent));
      stmt.finalize();
    }
  });
});

function broadcast(type, payload) {
  const message = JSON.stringify({ type, payload });
  WS_CLIENTS.forEach(client => {
    if (client.readyState === 1) client.send(message);
  });
}

// === API Routes ===

// Settings
app.get('/api/settings', (req, res) => {
  db.all("SELECT * FROM settings", [], (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    const settings = {};
    rows.forEach(row => settings[row.key] = row.value);
    res.json(settings);
  });
});

app.post('/api/settings', (req, res) => {
  const { key, value } = req.body;
  db.run("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)", [key, value], (err) => {
    if (err) return res.status(500).json({ error: err.message });
    broadcast('settings_updated', { key, value });
    res.json({ success: true });
  });
});

app.post('/api/settings/test', (req, res) => {
  const { key } = req.body;
  // Simulate connection test with realistic delay
  setTimeout(() => {
    const success = Math.random() > 0.15; // 85% success rate
    res.json({
      success,
      message: success ? `Successfully connected to ${key}` : `Connection to ${key} failed. Check credentials.`
    });
    if (success) broadcast('connection_healthy', { service: key });
  }, 850);
});

// Agents
app.get('/api/agents', (req, res) => {
  db.all("SELECT * FROM agents ORDER BY id", [], (err, rows) => {
    if (err) return res.status(500).json({error: err.message});
    res.json(rows);
  });
});

app.post('/api/agents/:id/toggle', (req, res) => {
  const { id } = req.params;
  db.get("SELECT status FROM agents WHERE id = ?", [id], (err, row) => {
    if (err || !row) return res.status(500).json({error: 'Agent not found'});
    const newStatus = row.status === 'active' ? 'paused' : 'active';
    db.run("UPDATE agents SET status = ? WHERE id = ?", [newStatus, id], (err) => {
      if (err) return res.status(500).json({error: err.message});
      broadcast('agent_updated', { id: parseInt(id), status: newStatus });
      res.json({ id: parseInt(id), status: newStatus });
    });
  });
});

// Clients & Pipeline
app.get('/api/clients', (req, res) => {
  db.all(`SELECT c.*, (SELECT COUNT(*) FROM activities WHERE client_id = c.id) as activity_count 
    FROM clients c ORDER BY created_at DESC`, [], (err, rows) => {
    if (err) return res.status(500).json({error: err.message});
    res.json(rows);
  });
});

app.post('/api/clients', (req, res) => {
  const { business_name } = req.body;
  if (!business_name) return res.status(400).json({error: "Business name required"});

  db.run("INSERT INTO clients (business_name, status, last_action, next_action) VALUES (?, 'prospect', 'Pipeline started', 'Research phase')", 
    [business_name], function(err) {
    if (err) return res.status(500).json({error: err.message});
    
    const clientId = this.lastID;
    
    db.run("INSERT INTO activities (client_id, agent_name, action, model, duration, result) VALUES (?, 'System', ?, 'System', 3, 'Pipeline initialized successfully')", 
      [clientId, `New client onboarded: ${business_name}`]);

    const stages = [
      {stage: 'prospect', agent: 'Outreach', status: 'completed'},
      {stage: 'research', agent: 'Researcher', status: 'in_progress'},
      {stage: 'build', agent: 'Builder', status: 'pending'},
      {stage: 'deploy', agent: 'Deployer', status: 'pending'},
      {stage: 'manage', agent: 'Outreach', status: 'pending'}
    ];
    
    const stmt = db.prepare("INSERT INTO pipeline_stages (client_id, stage, assigned_agent, status, approved) VALUES (?, ?, ?, ?, 0)");
    stages.forEach(s => stmt.run([clientId, s.stage, s.agent, s.status]));
    stmt.finalize();

    broadcast('new_client', { id: clientId, business_name });
    res.json({ id: clientId, business_name, status: 'prospect' });
  });
});

// Pipeline execution with model-aware simulation
app.post('/api/pipeline/:clientId/next', (req, res) => {
  const { clientId } = req.params;
  
  db.get(`SELECT ps.*, a.model as agent_model 
    FROM pipeline_stages ps 
    LEFT JOIN agents a ON ps.assigned_agent = a.name 
    WHERE ps.client_id = ? AND (ps.status = 'in_progress' OR ps.status = 'pending') 
    ORDER BY ps.id LIMIT 1`, [clientId], (err, stage) => {
    
    if (err || !stage) return res.status(404).json({error: 'No pending stage'});

    const model = stage.agent_model || 'Claude';
    const duration = Math.floor(Math.random() * 65) + 25;
    
    let action, result, resultDetail;

    switch(stage.stage) {
      case 'research':
        action = 'Conducted deep competitive and SEO research';
        result = 'High quality insights generated';
        resultDetail = model === 'Claude' ? 
          'Identified 14 competitors. Top keywords: sustainable branding, ethical sourcing. Opportunity score: 92/100.' : 
          'Discovered strong visual niche. Recommended hero imagery style and 6 core messages.';
        break;
      case 'build':
        action = 'Generated full production website';
        result = 'Beautiful responsive site created';
        resultDetail = 'Modern minimal design with smooth micro-interactions. Fully accessible, SEO optimized, mobile-first.';
        break;
      case 'deploy':
        action = 'Deployed to production';
        result = 'Live on custom domain';
        resultDetail = `https://${stage.client_id}-forge.netlify.app`;
        break;
      default:
        action = `Completed ${stage.stage} stage`;
        result = 'Success';
        resultDetail = 'Operation completed without issues.';
    }

    db.run(`INSERT INTO activities (client_id, agent_name, action, model, duration, result) 
      VALUES (?, ?, ?, ?, ?, ?)`, 
      [clientId, stage.assigned_agent, action, model, duration, resultDetail], () => {

      db.run("UPDATE pipeline_stages SET status = 'completed', approved = 1 WHERE id = ?", [stage.id]);

      db.get("SELECT * FROM pipeline_stages WHERE client_id = ? AND status = 'pending' ORDER BY id LIMIT 1", [clientId], (err, nextStage) => {
        let clientStatus = 'in_progress';
        if (nextStage) {
          db.run("UPDATE pipeline_stages SET status = 'in_progress' WHERE id = ?", [nextStage.id]);
          if (nextStage.stage === 'deploy' || nextStage.stage === 'manage') {
            db.run("INSERT INTO approvals (client_id, stage, message) VALUES (?, ?, ?)", 
              [clientId, nextStage.stage, `Please review before we go live with ${nextStage.stage} for this client.`]);
          }
        } else {
          clientStatus = 'managed';
        }

        db.run("UPDATE clients SET status = ?, last_action = ?, next_action = ? WHERE id = ?", 
          [clientStatus, action, nextStage ? `${nextStage.stage} in progress` : 'Ongoing management & growth', clientId]);

        const response = {
          success: true,
          stage: stage.stage,
          nextStage: nextStage?.stage || null,
          modelUsed: model,
          result: resultDetail
        };

        broadcast('activity', { ...response, clientId });
        res.json(response);
      });
    });
  });
});

app.get('/api/activities', (req, res) => {
  db.all(`SELECT a.*, c.business_name FROM activities a 
    LEFT JOIN clients c ON a.client_id = c.id 
    ORDER BY a.timestamp DESC LIMIT 30`, [], (err, rows) => {
    if (err) return res.status(500).json({error: err.message});
    res.json(rows);
  });
});

app.get('/api/approvals', (req, res) => {
  db.all(`SELECT a.*, c.business_name FROM approvals a 
    JOIN clients c ON a.client_id = c.id 
    WHERE a.status = 'pending' ORDER BY a.created_at DESC`, [], (err, rows) => {
    if (err) return res.status(500).json({error: err.message});
    res.json(rows);
  });
});

app.post('/api/approvals/:id/:action', (req, res) => {
  const { id, action } = req.params;
  const status = action === 'approve' ? 'approved' : 'rejected';

  db.get("SELECT * FROM approvals WHERE id = ?", [id], (err, approval) => {
    if (err || !approval) return res.status(404).json({error: 'Not found'});

    db.run("UPDATE approvals SET status = ? WHERE id = ?", [status, id]);

    if (action === 'approve') {
      db.run("UPDATE pipeline_stages SET status = 'completed', approved = 1 WHERE client_id = ? AND stage = ?", 
        [approval.client_id, approval.stage]);
      
      db.get("SELECT * FROM pipeline_stages WHERE client_id = ? AND status = 'pending' ORDER BY id LIMIT 1", 
        [approval.client_id], (err, next) => {
        if (next) {
          db.run("UPDATE pipeline_stages SET status = 'in_progress' WHERE id = ?", [next.id]);
        }
        db.run("UPDATE clients SET last_action = 'User approved live deployment', next_action = 'Active management' WHERE id = ?", 
          [approval.client_id]);
      });
    }

    db.run("INSERT INTO activities (client_id, agent_name, action, model, duration, result) VALUES (?, 'Human', ?, 'Human', 4, ?)", 
      [approval.client_id, `${action.toUpperCase()}D ${approval.stage}`, `User ${action}d sensitive operation.`]);

    broadcast('approval_resolved', { id: parseInt(id), action });
    res.json({ success: true, status });
  });
});

// WebSocket for real-time updates
const server = app.listen(PORT, () => {
  console.log(`🚀 Forge Server running on http://localhost:${PORT}`);
  console.log('📡 WebSocket ready at ws://localhost:' + PORT + '/ws');
  console.log('💾 Database ready at ' + dbPath);
});

const wss = require('ws').Server;
const wsServer = new wss({ server, path: '/ws' });

wsServer.on('connection', (ws) => {
  WS_CLIENTS.add(ws);
  console.log('Client connected to live updates');
  
  ws.send(JSON.stringify({ type: 'connected', message: 'Real-time updates active' }));

  ws.on('close', () => WS_CLIENTS.delete(ws));
});

// Catch all for SPA
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/dist/index.html'));
});
